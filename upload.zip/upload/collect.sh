#!/bin/bash
cd tmp_aweme_android
aweme_android_video=`ls -lt | grep mp4 | awk '{print $NF}'|sed -n 1p`
if [[ $aweme_android_video ]]; then
	ffmpeg -report -i $aweme_android_video
	log=`ls -lt | grep '.log' | awk '{print $NF}'|sed -n 1p`
	echo '{' >> aweme_android_video.json
	echo dpi:`more $log | grep 'Video:' | awk -F ',' '{print $5}'|awk -F ' ' '{print $1}'|awk -F 'x' '{print $1}'``more $log | grep 'Video:' | awk -F ',' '{print $5}'|awk -F ' ' '{print $1}'|awk -F 'x' '{print $2}'`, >> aweme_android_video.json
	echo data_rate:`more $log | grep 'Video:' | awk -F ',' '{print $6}'|awk -F ' ' '{print $1}'`, >> aweme_android_video.json
	echo fps:`more $log | grep 'Video:' | awk -F ',' '{print $7}'|awk -F ' ' '{print $1}'` >> aweme_android_video.json
	echo '}' >> aweme_android_video.json
	# rm -rf *.log
fi
cd ..
cd tmp_aweme_ios
aweme_ios_video=`ls -lt | grep mp4 | awk '{print $NF}'|sed -n 1p`
if [[ $aweme_ios_video ]]; then
	ffmpeg -report -i $aweme_ios_video
	log=`ls -lt | grep '.log' | awk '{print $NF}'|sed -n 1p`
	echo '{' >> aweme_ios_video.json
	echo dpi:`more $log | grep 'Video:' | awk -F ',' '{print $5}'|awk -F ' ' '{print $1}'|awk -F 'x' '{print $1}'``more $log | grep 'Video:' | awk -F ',' '{print $5}'|awk -F ' ' '{print $1}'|awk -F 'x' '{print $2}'`, >> aweme_ios_video.json
	echo data_rate:`more $log | grep 'Video:' | awk -F ',' '{print $6}'|awk -F ' ' '{print $1}'`, >> aweme_ios_video.json
	echo fps:`more $log | grep 'Video:' | awk -F ',' '{print $7}'|awk -F ' ' '{print $1}'` >> aweme_ios_video.json
	echo '}' >> aweme_ios_video.json
	rm -rf *.log
fi