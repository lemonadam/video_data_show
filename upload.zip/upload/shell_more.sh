#!/bin/bash
sleep 2s
more  video.log