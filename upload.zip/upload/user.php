<?php
$output = shell_exec('pwd');
echo $output;
?>