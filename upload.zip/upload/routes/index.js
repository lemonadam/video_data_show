
/*
 * GET home page.
 */
//
// exports.index = function(req, res){
//   res.render('show', { title: 'Express' });
// };

exports.index = function(req, res){
  res.render('show', { title: 'ejs' });};